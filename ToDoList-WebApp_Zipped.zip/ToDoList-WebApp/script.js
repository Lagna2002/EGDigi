let users = {};

document.getElementById('registerButton').addEventListener('click', function() {
    const username = document.getElementById('regUsername').value;
    const password = document.getElementById('regPassword').value;
    
    if (username && password) {
        users[username] = {
            password: btoa(password), // Simple encoding for demo purposes
            tasks: []
        };
        alert('Registration successful!');
        document.getElementById('regUsername').value = '';
        document.getElementById('regPassword').value = '';
    } else {
        alert('Please fill out all fields.');
    }
});

document.getElementById('loginButton').addEventListener('click', function() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    if (users[username] && users[username].password === btoa(password)) {
        document.getElementById('auth').style.display = 'none';
        document.getElementById('todo').style.display = 'block';
        document.getElementById('usernameDisplay').innerText = username;
        loadTasks(username);
    } else {
        alert('Invalid username or password.');
    }
});

document.getElementById('addTaskButton').addEventListener('click', function() {
    const task = document.getElementById('newTask').value;
    const username = document.getElementById('usernameDisplay').innerText;

    if (task) {
        users[username].tasks.push(task);
        document.getElementById('newTask').value = '';
        loadTasks(username);
    }
});

document.getElementById('logoutButton').addEventListener('click', function() {
    document.getElementById('auth').style.display = 'block';
    document.getElementById('todo').style.display = 'none';
});

function loadTasks(username) {
    const taskList = document.getElementById('taskList');
    taskList.innerHTML = '';
    users[username].tasks.forEach((task, index) => {
        const li = document.createElement('li');
        li.innerText = task;
        taskList.appendChild(li);
    });
}
