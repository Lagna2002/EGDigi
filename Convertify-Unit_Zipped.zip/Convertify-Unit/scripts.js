document.getElementById('convertButton').addEventListener('click', function() {
    const inputValue = parseFloat(document.getElementById('inputValue').value);
    const inputUnit = document.getElementById('inputUnit').value;
    const outputUnit = document.getElementById('outputUnit').value;

    let conversionRate = getConversionRate(inputUnit, outputUnit);
    let outputValue = inputValue * conversionRate;

    document.getElementById('outputValue').innerText = outputValue.toFixed(2);
});

function getConversionRate(inputUnit, outputUnit) {
    const conversionRates = {
        'meters': 1,
        'kilometers': 0.001,
        'grams': 1,
        'kilograms': 0.001,
        'liters': 1,
        'celsius': 1 // Custom logic needed for temperature conversion
        // Add more units and their conversion rates relative to a base unit
    };

    return conversionRates[outputUnit] / conversionRates[inputUnit];
}
